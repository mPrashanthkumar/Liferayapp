package com.cloud.tags.common;

import static com.rosaloves.bitlyj.Bitly.as;
import static com.rosaloves.bitlyj.Bitly.shorten;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpSession;

import org.imgscalr.Scalr;

import com.cloud.tags.model.CartsDesigners;
import com.liferay.portal.NoSuchUserException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.image.ImageBag;
import com.liferay.portal.kernel.image.ImageToolUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.FileUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.rosaloves.bitlyj.Url;
/**
 * 
 * @author Mohammed Zaheer
 *
 */
public class CommonUtil {
	private static Log _log = LogFactoryUtil.getLog(CommonUtil.class);

	public static File getThumbnail(File file, String contentType) {
		byte[] bytes = null;
		ImageBag imageBag = null;

		if (Validator.isNull(file))
			return null;

		try {
			imageBag = ImageToolUtil.read(file);
		} catch (IOException e) {
			_log.debug("Error while reading file");
		}
		if (Validator.isNull(imageBag))
			return null;

		RenderedImage renderedImage = imageBag.getRenderedImage();

		long height = 250; // Math.round(image.getHeight() * reduceBy);
		long width = 250;// Math.round(image.getWidth() * reduceBy);
		renderedImage = ImageToolUtil.scale(renderedImage, (int) height,
				(int) width);
		try {
			bytes = ImageToolUtil.getBytes(renderedImage, contentType);
		} catch (IOException e) {
			_log.debug("Error while converting to bytes");
		}
		File thumbnailfile = null;
		try {
			thumbnailfile = FileUtil.createTempFile(bytes);
		} catch (IOException e) {
			_log.debug("Unable to create file");
		}

		return thumbnailfile;
	}

	public static String getThumnail(String path, long designId, long groupId) {

		String smallImageURL = StringPool.BLANK;

		try {
			URL url = new URL(path);
			URLConnection conn = url.openConnection();
			InputStream in =  conn.getInputStream();			
			File file = FileUtil.createTempFile(in);
			
			String thumnailPath = "uploads" + StringPool.SLASH + "designers"
					+ StringPool.SLASH + groupId + StringPool.SLASH
					+ "entity_image1" + StringPool.SLASH + designId
					+ StringPool.SLASH + "thumb" + StringPool.SLASH
					+ getFileName(path);

			String contentType = URLConnection.guessContentTypeFromStream(in);
			file = getThumbnail(file, contentType);
			S3Util.uploadToS3(file, contentType, thumnailPath);

			smallImageURL = PropsUtil.get("s3.image.url")
					+ PropsUtil.get("aws.bucket") + StringPool.SLASH
					+ thumnailPath;

		} catch (MalformedURLException e) {
			_log.debug("Error while reading image from URL ");

		} catch (IOException e) {
			_log.debug("Error while reading image from URL ");

		}

		System.out.println("smallImageURL"+smallImageURL);
		return smallImageURL;
	}

	public static String getFileName(String url) {
		String fileName;
		int slashIndex = url.lastIndexOf("/");
		int qIndex = url.lastIndexOf("?");
		if (qIndex > slashIndex) {// if has parameters
			fileName = url.substring(slashIndex + 1, qIndex);
		} else {
			fileName = url.substring(slashIndex + 1);
		}
		if (fileName.contains(".")) {
			fileName = fileName.substring(0, fileName.lastIndexOf("."));
		}

		return fileName;
	}

	
	public static String getTiyURL(String longURL,String loginId, String apiKey){
		
		String tinyURL = "";
		try{
			Url url = as(loginId, apiKey).call(shorten(longURL));
			tinyURL = url.getShortUrl();
		}catch(Exception e){
			_log.error("could not get the short URL"+e.getMessage());
		}
		return tinyURL;
		
	}
	
	public static long getUserByEmail(String emailAddress,long companyId){
		
		long userId = 0l;
		
		try{
			
			userId = UserLocalServiceUtil.getUserByEmailAddress(companyId, emailAddress).getUserId();
			
		}catch(NoSuchUserException nse){
			_log.warn("No user exits create new"+nse.getMessage());
			try {
				
				User user =  UserLocalServiceUtil.addUser(
						0l, 				// creatorUserId
						companyId,		 	// companyId
						true,			 	// autoPassword
						"", 				// password1,
						"", 				// password2,
						true, 				// autoScreenName,
						"", 			// screnName,
						emailAddress, 				// need to check how to update thisemailAddress,
						0l, 				// facebookId,
						"", 				// openId,
						Locale.getDefault(),//locale
						emailAddress, 			// firstName,
						"", 		// middleName,
						"", 			// lastName,
						0, 					// prefixId,
						0, 					// suffixId,
						true,				// male,
						1, 					// birthdayMonth,
						1, 					// birthdayDay,
						1970, 				// birthdayYear,
						"",  				// jobTitle,
						null,				// groupIds,
						null,				// organizationIds,
						null,				// roleIds,
						null,				// userGroupIds,
						true, 				// sendEmail,
						new ServiceContext());
				//ElasticIndexUtil.indextDataToElasticSearch(user, "user", "userdetails");
				
				userId = user.getUserId();
			} catch (PortalException e) {
				e.printStackTrace();
				_log.warn("No user exits create new"+e.getMessage());
			} catch (SystemException e) {
				e.printStackTrace();
				_log.warn("No user exits create new"+e.getMessage());
			}
			
		} catch (PortalException e) {
			_log.warn("No user exits create new"+e.getMessage());
		} catch (SystemException e) {
			_log.warn("No user exits create new"+e.getMessage());
		}
		
		_log.info("User object"+userId);
		
		return userId;
		
	}
	/**
	 * 
	 * @param originalImage
	 * @param type
	 * @param IMG_WIDTH
	 * @param IMG_HEIGHT
	 * @return
	 */
	@SuppressWarnings("unused")
	public static String multiDimensions(String path, long designerId, long companyId, boolean isFirstImage){
		
		
		String productImageURL = StringPool.BLANK;

		try {
			if(!path.trim().equalsIgnoreCase("")){
			URL url = new URL(path);
			URLConnection conn = url.openConnection();

			InputStream in =  conn.getInputStream();
			
			File file = FileUtil.createTempFile(in);
			
			String thumnailPath = "uploads" + StringPool.SLASH + "designers"
					+ StringPool.SLASH +"images"+ StringPool.SLASH+ designerId
					+ StringPool.SLASH 
					+"600x400"+StringPool.SLASH+ getFileName(path)+".jpg";

			String contentType = "image/jpeg";
			System.out.println("************************************"+contentType);
			file = getImageWithDimensions(file, contentType, 600, 400,thumnailPath );			
			S3Util.uploadToS3(file, contentType, thumnailPath);
			
			productImageURL = PropsUtil.get("s3.image.url")
					+ PropsUtil.get("aws.bucket") + StringPool.SLASH
					+ thumnailPath;
			URL url1 = new URL(productImageURL);
			URLConnection conn1 = url1.openConnection();

			InputStream in1 =  conn1.getInputStream();
			
			File file1 = FileUtil.createTempFile(in1);
			if(isFirstImage){
			String smallPath = "uploads" + StringPool.SLASH + "designers"
					+ StringPool.SLASH +"images"+ StringPool.SLASH+ designerId
					+ StringPool.SLASH
					+"217X161"+StringPool.SLASH+getFileName(path)+".jpg";
			
			file = getImageWithDimensions(file1, contentType, 217, 161,getFileName(path)+".jpg");
			S3Util.uploadToS3(file, contentType, smallPath);
			String listPath = "uploads" + StringPool.SLASH + "designers"
					+ StringPool.SLASH +"images"+ StringPool.SLASH+ designerId
					+ StringPool.SLASH
					+"330X200"+StringPool.SLASH+getFileName(path)+".jpg";
			
			file = getImageWithDimensions(file1, contentType, 330, 200,listPath);
			S3Util.uploadToS3(file, contentType, listPath);
			}
			
			in1.close();
			in.close();
			}
			

		} catch (MalformedURLException e) {
			_log.debug("Error while reading image from URL ");

		} catch (IOException e) {
			_log.debug("Error while reading image from URL ");

		}

		System.out.println("productImageURL"+productImageURL);
		return productImageURL;
		

	    }
	/**
	 * 
	 * @param file
	 * @param contentType
	 * @param height
	 * @param width
	 * @return
	 */
	public static File getImageWithDimensions(File file, String contentType,int height,int width, String name) {
		byte[] bytes = null;
		ImageBag imageBag = null;

		if (Validator.isNull(file))
			return null;

		try {
			imageBag = ImageToolUtil.read(file);
		} catch (IOException e) {
			_log.debug("Error while reading file");
		}

		BufferedImage originalImage = null;
		try {
			originalImage = ImageIO.read(file);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		BufferedImage resizeImageJpg =Scalr.resize(
				originalImage, 
				Scalr.Method.QUALITY, 
				Scalr.Mode.FIT_EXACT,
				height, 
				width, 
				Scalr.OP_ANTIALIAS);
		//File thumbnailfile = new File("C:\\Zaheer\\Cloudtags\\Imagetesting\\images\\"+file.getName()+".jpg");
		//File thumbnailfile = new File("/home/deploy/madePlatform/liferay-portal-6.2.0-ce-ga1/AWS-Images/"+file.getName()+".jpg");
		File thumbnailfile = new File("/var/www/liferay/liferay-portal-6.2.0-ce-ga1/AWS-Images/"+file.getName()+".jpg");

		try {
			ImageIO.write(resizeImageJpg, "jpg",thumbnailfile );
			
			//thumbnailfile = new File("C:\\Zaheer\\Cloudtags\\Imagetesting\\images\\"+file.getName());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		
		
		
		return thumbnailfile;
	}
	public static String getTabCurrent(String path,  boolean isTabcurrent){
		String imageUrl = path;
		String awsURI = PropsUtil.get("s3.image.url")
				+ PropsUtil.get("aws.bucket");
		String tabCurrentURL = PropsUtil.get("tablet.current.url");
		if(isTabcurrent){
			imageUrl = imageUrl.replace(awsURI, tabCurrentURL);
		}else{
			return imageUrl;
		}
		return imageUrl;
		
	}
	public static Map<Long, CartsDesigners> mergelikedAdded(Map<Long, CartsDesigners> liked, Map<Long, CartsDesigners> added) {
		Map<Long, CartsDesigners> marsterMap = new HashMap<Long, CartsDesigners>();
		long i=1;
		for(CartsDesigners cartDesigner : liked.values()){
			marsterMap.put(i, cartDesigner);
			i++;
		}
	    for (CartsDesigners cartDesigner : added.values()) {
	        if (!liked.containsValue(cartDesigner)) {	           
	        	marsterMap.put(i,cartDesigner);
	        	i++;
	        } 
	    }
	    return marsterMap;
	}
	public static String getCartId(long designerId, Map<Long, CartsDesigners> marsterMap,HttpSession session) {		
		String catId=StringPool.BLANK;
		for(CartsDesigners cartDesigner : marsterMap.values()){
			if(cartDesigner.getDesignId() == designerId){
				catId = session.getAttribute("CARTID").toString();
				System.out.println("<><><>>>>>>>>>>>>>>>>>>>>>>>"+cartDesigner.getCartDesignerId());
				break;				
			}
			
		}
	   
	    return catId;
	}
}

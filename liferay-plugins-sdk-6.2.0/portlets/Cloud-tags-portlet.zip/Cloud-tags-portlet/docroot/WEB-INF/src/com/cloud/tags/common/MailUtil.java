package com.cloud.tags.common;

import javax.mail.internet.InternetAddress;

import org.apache.log4j.Logger;

import com.liferay.mail.service.MailServiceUtil;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.journal.model.JournalArticle;
import com.liferay.portlet.journal.service.JournalArticleLocalServiceUtil;
import com.sendgrid.SendGrid;
import com.sendgrid.SendGridException;
import com.sendgrid.smtpapi.SMTPAPI;

public class MailUtil {
	private final static Logger _log = Logger.getLogger(MailUtil.class
			.getName());

	public static String getContent(String articleName,
			ThemeDisplay themeDisplay) {
		String emailTemplate = StringPool.BLANK;

		JournalArticle journal = null;

		try {
			journal = JournalArticleLocalServiceUtil.getArticleByUrlTitle(
					themeDisplay.getScopeGroupId(), articleName);

		} catch (Exception e) {
			_log.warn(e.getMessage());

		}

		if (Validator.isNotNull(journal))
			emailTemplate = journal.getContent();
		emailTemplate = emailTemplate.replace("<![CDATA[", "");
		emailTemplate = emailTemplate.replace("]]>", "");

		return emailTemplate;

	}

	public static void sendEmail(String emailAddress, String emailTemplate) {
		try {
			
			
			String subject = "Your Collection from Made.com";

			InternetAddress fromAddress = new InternetAddress(
					"no-reply@made.com", "Made.com");
			InternetAddress to = new InternetAddress(emailAddress,
					"");
			_log.info("fromAddress>>>>"+fromAddress);
			_log.info("toAddress>>>>"+to);
			MailMessage message = new MailMessage(fromAddress, to, subject,
					emailTemplate, true);
			
			
			//MailServiceUtil.sendEmail(message);
			//SendGrid Java API for sending mails - starts
			
			SendGrid sendgrid = new SendGrid(PropsUtil.get("sendgrid.user.name"), PropsUtil.get("sendgrid.user.password"));
			 
			  
		    SendGrid.Email email = new SendGrid.Email();
		    email.addCategory(PropsUtil.get("sendgrid.email.category"));
		    //email.addCategory("MADE.COM");
		    email.addTo(emailAddress);
		    email.setFrom(PropsUtil.get("sendgrid.from.email"));
		    email.setFromName(PropsUtil.get("sendgrid.from.name"));
		    email.setSubject(subject);
		    email.setHtml(emailTemplate);

		    try {
		      SendGrid.Response response = sendgrid.send(email);
		      System.out.println(response.getMessage());
		    }
		    catch (SendGridException e) {
		      System.err.println(e);
		    }
		  
			
			//Ends

		} catch (Exception e) {
			_log.warn(e.getMessage());

		}
	}

}
package com.cloud.tags.portlet.recommendation;

import java.io.IOException;
import java.util.HashMap;
import java.util.UUID;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cloud.tags.model.Carts;
import com.cloud.tags.model.CartsDesigners;
import com.cloud.tags.model.Designers;
import com.cloud.tags.service.CartsDesignersLocalServiceUtil;
import com.cloud.tags.service.CartsLocalServiceUtil;
import com.cloud.tags.service.DesignersLocalServiceUtil;
import com.cloud.tags.service.ImpressionsLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
/**
 * @author Azam
 * @author Mohammed zaheer
 * Portlet implementation class Recommendationcontroller
 * this class manages each of products added to selected and displayed in designers page
 */
public class Recommendationcontroller extends MVCPortlet {

	private final static Logger _log = Logger
			.getLogger(Recommendationcontroller.class.getName());

	@Override
	public void init() throws PortletException {
		// TODO Auto-generated method stub
		super.init();
	}
	/**
	 * This method manages each product added to CART and stores the values into DB
	 */
	@SuppressWarnings("unchecked")
	public void serveResource(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) throws IOException,
			PortletException {

		// Future store records into CARt table per userIDs
		UploadPortletRequest uploadPortletRequest = PortalUtil
				.getUploadPortletRequest(resourceRequest);
		HttpSession session = PortalUtil.getHttpServletRequest(resourceRequest)
				.getSession();
		
		String loginUser = StringPool.BLANK;
		if(Validator.isNotNull(session.getAttribute("LOGIN-USER"))){
			System.out.println("LOGIN-USER inside recommendations if");
			loginUser = session.getAttribute("LOGIN-USER").toString();
		}
		
		String cmd = ParamUtil.getString(uploadPortletRequest, "CMD");
		if(cmd.equals("ADDED2CART")){
			_log.info("Insided added cart");
			
			
			ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest
					.getAttribute(WebKeys.THEME_DISPLAY);
			long productId = ParamUtil.getLong(uploadPortletRequest, "productId");
	
			HashMap<Long, Designers> cartList = null;// new HashMap<Long,
														// Designers>();
			HashMap<Long, CartsDesigners> cartDesigners = null;
			
	
			Designers designers = null;
			try {
	
				designers = DesignersLocalServiceUtil.getDesigners(productId);
	
				if (Validator.isNotNull(session.getAttribute("LIFERAY_SHARED_CARTLIST"))) {
	
					cartList = (HashMap<Long, Designers>) session
							.getAttribute("LIFERAY_SHARED_CARTLIST");
	
				} else {
	
					cartList = new HashMap<Long, Designers>();
				}
				cartList.put(productId, designers);
				session.setAttribute("LIFERAY_SHARED_CARTLIST", cartList);
	
			} catch (PortalException e) {
				_log.error(e.getMessage());
			} catch (SystemException e) {
				_log.error(e.getMessage());
			}
	
			// This is added to track the cart and the designers
	
			try {
	
				//logic need to be changed by checking the cart Id exists or not if yes dont create new cart else create new cart obj
				
				Carts carts = null;
				
				//System.out.println(session.getAttribute("CARTID"));
				if (Validator.isNotNull(session.getAttribute("CARTID"))) {
					
					try {
						System.out.println("inside try>>>>>>>>>>>>");
						carts = CartsLocalServiceUtil.getCarts( (Long)session.getAttribute("CARTID"));
						session.setAttribute("CARTID", carts.getCartId());
	
					} catch (NumberFormatException e) {
						e.printStackTrace();
					} catch (PortalException e) {
						e.printStackTrace();
					}
	
				} else {
					 carts = CartsLocalServiceUtil.addToCarts(themeDisplay.getUserId());
					 
						session.setAttribute("CARTID", carts.getCartId());
						try {
							if(Validator.isNotNull(session.getAttribute("LOGIN-USER"))){
								System.out.println("LOGIN-USER inside recommendations if");
								//loginUser = session.getAttribute("LOGIN-USER").toString();
								carts.setSession_id(session.getAttribute("LOGIN-USER").toString());							
							}
							if(Validator.isNotNull(session.getAttribute("LOGINSTAFF"))){
								System.out.println("LOGINSTAFF inside recommendations if");
								carts.setStaffId(session.getAttribute("LOGINSTAFF").toString());
							}
							CartsLocalServiceUtil.updateCarts(carts);
							ImpressionsLocalServiceUtil.addToImpressions("CARTS", Long.toString(carts.getCartId()), "ADDED",loginUser , Long.toString(themeDisplay.getCompanyId()), PortalUtil.getHttpServletRequest(resourceRequest).getRemoteAddr());
	
									
						}catch (Exception e) {
							e.printStackTrace();
						}
				}
				
	
				
				if (Validator.isNotNull(session.getAttribute("LIFERAY_SHARED_CARTDESIGNERS"))) {
					
					cartDesigners = (HashMap<Long, CartsDesigners>) session
							.getAttribute("LIFERAY_SHARED_CARTDESIGNERS");
					
				} else {
					cartDesigners = new HashMap<Long, CartsDesigners>();
				}
	
				if (cartDesigners.size() == 0 || !cartDesigners.containsKey(productId)) {
	
					if (Validator.isNotNull(carts)) {
						
						CartsDesigners cartsDesigners = CartsDesignersLocalServiceUtil
								.addDesignerToCarts(carts.getCartId(), productId,
										true);
						 ImpressionsLocalServiceUtil.addToImpressions("CART-PRODUCT", Long.toString(cartsDesigners.getCartDesignerId()), "ADDED",loginUser , Long.toString(themeDisplay.getCompanyId()), PortalUtil.getHttpServletRequest(resourceRequest).getRemoteAddr());
	
						cartDesigners.put(productId, cartsDesigners);
						session.setAttribute("LIFERAY_SHARED_CARTDESIGNERS",
								cartDesigners);
					}
	
				}
			} catch (SystemException e) {
	
				_log.error(e.getMessage());
			}
		}else if(cmd.equals("LIKED")){
			_log.info("Insided liked cart");
			
				
				
				ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest
						.getAttribute(WebKeys.THEME_DISPLAY);
				
				
				long productId = ParamUtil.getLong(uploadPortletRequest, "productId");
	
				HashMap<Long, Designers> cartList = null;// new HashMap<Long,
															// Designers>();
				//HashMap<Long, CartsDesigners> cartDesigners = null;
				
				Designers designers = null;
				try {
		
					designers = DesignersLocalServiceUtil.getDesigners(productId);
		
					if (Validator.isNotNull(session.getAttribute("LIFERAY_LIKED_CARTLIST"))) {
		
						cartList = (HashMap<Long, Designers>) session
								.getAttribute("LIFERAY_LIKED_CARTLIST");
		
					} else {
		
						cartList = new HashMap<Long, Designers>();
					}
					cartList.put(productId, designers);
					session.setAttribute("LIFERAY_LIKED_CARTLIST", cartList);
					
					designers.setLiked(designers.getLiked()+1);
					DesignersLocalServiceUtil.updateDesigners(designers);
					
					Carts carts = CartsLocalServiceUtil.getCarts((Long)session.getAttribute("CARTID"));
					CartsDesigners cartsDesigners = CartsDesignersLocalServiceUtil.findBycartIdDesignId(carts.getCartId(), productId);
					
					cartsDesigners.setFavorite(true);
					CartsDesignersLocalServiceUtil.updateCartsDesigners(cartsDesigners);	
					
					
					_log.info(">>>>>>>>>>>>>"+cartsDesigners.getFavorite());
					
					
					ImpressionsLocalServiceUtil.addToImpressions("CART-PRODUCT", Long.toString(cartsDesigners.getCartDesignerId()), "LIKED",loginUser , Long.toString(themeDisplay.getCompanyId()), PortalUtil.getHttpServletRequest(resourceRequest).getRemoteAddr());
					
		
				} catch (PortalException e) {
					_log.error(e.getMessage());
				} catch (SystemException e) {
					_log.error(e.getMessage());
				}
			}

	}
	
	@Override
	public void doView(RenderRequest renderRequest,
			RenderResponse renderResponse) throws IOException, PortletException {
		// TODO Auto-generated method stub
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest
				.getAttribute(WebKeys.THEME_DISPLAY);
		HttpSession session = PortalUtil.getHttpServletRequest(renderRequest)
				.getSession();
		if(Validator.isNull(session.getAttribute("LOGIN-USER"))){
			UUID idOne = UUID.randomUUID();
			session.setAttribute("LOGIN-USER", idOne.toString());
		try {
			ImpressionsLocalServiceUtil.addToImpressions("USER", Long.toString(themeDisplay.getUserId()), "LOGIN",idOne.toString() , Long.toString(themeDisplay.getCompanyId()),PortalUtil.getHttpServletRequest(renderRequest).getRemoteAddr());
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		super.doView(renderRequest, renderResponse);
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
	}
}
